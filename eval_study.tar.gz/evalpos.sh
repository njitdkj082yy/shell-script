#!/bin/bash
echo "The number of arguments passed to this script:$#"
echo -n "The last argument is:"
#eval echo \$$#
echo \$$#
