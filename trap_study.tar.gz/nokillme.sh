#!/bin/bash
trap "" TERM INT
while (( i < 30 ))
do
	sleep 1
	let i=i+1
done
echo "over"
