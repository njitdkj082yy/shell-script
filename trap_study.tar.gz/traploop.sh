#!/bin/bash
trap "echo 'You hit CONTROL+C!'" INT

while :;do
    let count=count+1
    echo "This is the $count sleep"
    sleep 2
done
