#!/bin/bash
trap "" QUIT
trap "echo 'You want to kill me'" TERM
(
	./forever.sh
)
