#!/bin/bash 
echo "Father Process ID is $$"
localvalue="Define a local variable."
echo "localvar=$localvalue"

ENVVAR="Define a environment variable."
export ENVVAR
echo "ENVVAR=$ENVVAR"

$PWD/child.sh

echo "Return to father process: $$"
echo "localval=$localvalue"
echo "ENVVAR=$ENVVAR"
