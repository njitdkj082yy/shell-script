#!/bin/bash 
echo "Child Process ID is $$"
echo "My Father Process ID is $PPID"
echo "localval=$localvalure"
echo "ENVVAR=$ENVVAR"

localvalure="Redefine this local variable."
ENVVAR="Redefine this environment variable."
echo "localvalure=$localvalure"
echo "ENVVAR=$ENVVAR"
