#!/bin/bash 
c=""
echo "c=$c"
let "c+=1"
echo "c=$c"

echo "e=$e"
let "e+=1"
echo "e=$e"
exit 0
